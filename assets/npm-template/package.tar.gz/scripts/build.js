const { execSync } = require('child_process');

function build() {
    execSync('yarn run build', { stdio: 'inherit' });
}

build();
