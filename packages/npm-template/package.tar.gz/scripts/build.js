const { execSync } = require('child_process');

function build() {
    execSync('yarn run build');
}

build();
